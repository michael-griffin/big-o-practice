// add whatever parameters you deem necessary & write docstring
function sameFrequency() {
}
